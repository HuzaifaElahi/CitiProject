// // vue.config.js for less-loader@6.0.0
// module.exports = {
//   css: {
//     loaderOptions: {
//       less: {javascriptEnabled: true}
//     },
//     javascriptEnabled: true
//   }
// }
  