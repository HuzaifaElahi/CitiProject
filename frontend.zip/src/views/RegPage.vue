<template>
  <div id="reg">
  <register/>
  </div> 
</template>

<script>
import register from '../components/register.vue'
export default {
  name: 'reg',
  components: {
    register
  }
}
</script>