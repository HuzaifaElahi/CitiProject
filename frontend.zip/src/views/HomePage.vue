<template>
  <div id="Home">
  <home/>
  </div> 
</template>

<style>

</style>
<script>
import home from '../components/home.vue'
export default {
  name: 'Home',
  components: {
    home
  }
}
</script>